This is interior design website. 
Language: php, javascript


for run this,
1. unzip downloaded file.
2. Then start "Apache" server.
3. Then go to xampp -> htdocs.
4. In the htdocs folder, keep the unzip downloaded file.
5. Then write "localhost/interior/" in the browser.