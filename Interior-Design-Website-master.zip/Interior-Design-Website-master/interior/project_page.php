<!DOCTYPE html>
<html>

<head>
   <link rel="stylesheet" type="text/css" href="CSS/notice.css">
  <div align="center">
    <header>
      <img src="upload_pic/logo.jpg">
    </header>
  </div>
</head>

<body style="background-color: #FFFFFF">

  <!-- ************************ Buttons *************************** -->
  <div align="center">
    <a href="home_page.php"><button class="button" ><span>Home</span></button></a>
    <a href="about_page.php"><button class="button" ><span>About Us</span></button></a>
    <a href="service_page.php"><button class="button" ><span>Services</span></button></a>
      
      
    <div class="dropdown">
        <button class="dropbtn">Gallery</button>
        <div class="dropdown-content">
            <a href="bed_room.php">Bedroom</a>
            <a href="dining_room.php">Dining Room</a>
            <a href="drawing_room.php">Drawing Room</a>
            <a href="kitchen_room.php">Kitchen</a>
            <a href="study_room.php">Study Room</a>
        </div>
    </div>
      
      
    <a href="project_page.php"><button class="button" ><span>Project</span></button></a>
    <a href="contact_page_user.php"><button class="button" ><span>Contact</span></button></a>
  </div>
  <!-- ************************ Description *************************** -->

  <div style="background-color:#5f2160; color:white;padding:20px; text-align:center; margin: 35px; width: 92%;">

    <h2> <b></b> Our Recent Project </h2>
    </div>
   <table style="width:95%;padding:20px;margin: 35px;" id="t01">
  <tr>
    <th> Client Name </th>
    <th> Place </th>
	 <th> Work Type </th>
  </tr>
  
   <tr>
    <td> TARA SPINNING LTD</td>
    <td>Gulshan	</td>
	<td>C Residential Interior Design</td>
  </tr>
  
  <tr>
    <td> HOTEL ORNATE</td>
    <td> Paltan	</td>
	<td>Residential Hotel Interior</td>
  </tr>
  
  <tr>
    <td>FOREST BRAND SHOWROOM</td>
    <td> Uttara</td>
	<td> Showroom Interior </td>
  </tr>
  <tr>
    <td> TOWER TRADE</td>
    <td>Motijheel	</td>
	<td>Corporate office Interior</td>
  </tr>
  
  
</table>


 
  <div align="center">
    <footer>Copyright © 2017 Nicdos Interior. All rights reserved.</footer>
  </div>

</body>

</html>